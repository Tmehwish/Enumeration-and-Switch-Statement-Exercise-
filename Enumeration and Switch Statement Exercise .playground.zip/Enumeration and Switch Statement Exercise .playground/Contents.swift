import UIKit

enum Sandwich: CaseIterable {
    case italianBread
    case lettuce
    case cucumbers
    case tomato
    case americanCheese
    case creamySriracha
    case bananaPeppers
    case oliveOil
}
let numberOfChoices = Sandwich.self.allCases.count
print("My sandwich will have the following \(numberOfChoices) ingredents: \(Sandwich.italianBread), \(Sandwich.lettuce), \(Sandwich.cucumbers), \(Sandwich.tomato), \(Sandwich.americanCheese), \(Sandwich.creamySriracha), \(Sandwich.bananaPeppers), and \(Sandwich.oliveOil) ")

    


